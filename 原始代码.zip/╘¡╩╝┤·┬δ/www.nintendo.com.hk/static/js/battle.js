/*
 *
 * File Name : battle.js [use jquery]
 *
 */



var battle = (function(){
  var _battleTxt = $('#battleTxt').find('dl');

  // top slide
  var mySwiperTop = new Swiper ('#battleModeListInner', {
    loop: true,
    nextButton: '#btnBattleNext',
    prevButton: '#btnBattlePrev',
    spaceBetween: 30,
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: 'auto',

    onInit : function(swiper){
      $(document).on('click', '#battleModeListInner .movie', function(){
        var _this = $(this);
        var ytID = _this.attr('data-ytid');
        var ytBox = _this.find('.yt');
        var ytBoxID = ytBox.attr('id');

        var youtubeHtml = '<iframe id="player_'+ ytBoxID +'" width="480" height="270" src="https://www.youtube.com/embed/'+ ytID +'?rel=0&amp;showinfo=0&enablejsapi=1&controls=0&autoplay=1" frameborder="0" allowfullscreen></iframe>';
        ytBox.append(youtubeHtml);

        // setTimeout(function(){
        //   videoControl('mute', 'player_'+ytBoxID);
        //   videoControl('playVideo', 'player_'+ytBoxID);
        // },1000);
      });
    },

    onSlideChangeStart : function(swiper){
      var realIndex = swiper.realIndex;

      _battleTxt.removeClass('active').eq(realIndex).addClass('active');
    },

    onSlideChangeEnd : function(swiper){
      $('.swiper-wrapper').find('iframe').remove();
    }
  });


  var ua = navigator.userAgent.toLowerCase();
  var ver = navigator.appVersion.toLowerCase();
  var isMSIE = (ua.indexOf('msie') > -1) && (ua.indexOf('opera') == -1);
  var isIE11 = (ua.indexOf('trident/7') > -1);
  var isIE = isMSIE || isIE11;

  var useCSS = true;
  if(isIE) {
    useCSS = false;
  }
  else {
    useCSS = true;
  }

  $('#stageWrap ul').bxSlider({
    minSlides: 3,
    maxSlides: 5,
    slideWidth: 400,
    slideMargin: 0,
    ticker: true,
    tickerHover: true,
    speed: 30000,
    useCSS: useCSS
  });
})();
