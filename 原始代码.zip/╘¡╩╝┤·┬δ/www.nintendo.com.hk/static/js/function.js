/*
 *
 * File Name : function.js [use jquery]
 *
 */




/*********************************************************************************************/
// ブラウザチェック
// ex) if(util.isTablet){ ... } // true or false
/*********************************************************************************************/
var util = (function(u){
  return {
    isTablet:(u.indexOf("windows") != -1 && u.indexOf("touch") != -1 && u.indexOf("tablet pc") == -1) || u.indexOf("ipad") != -1 || (u.indexOf("android") != -1 && u.indexOf("mobile") == -1),

    isAndroid:(u.indexOf("windows") != -1 && u.indexOf("phone") != -1) || (u.indexOf("android") != -1 && u.indexOf("mobile") != -1),

    isIOS:(u.indexOf("windows") != -1 && u.indexOf("phone") != -1) || u.indexOf("iphone") != -1 || u.indexOf("ipod") != -1,

    isWebview:(/iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase()) && /twitter|fbav|line/.test(navigator.userAgent.toLowerCase()))
  };
})(window.navigator.userAgent.toLowerCase());
/*********************************************************************************************/




/*********************************************************************************************/
// ブラウザのビューポートチェック
// ex) if(viewportCheck.isSP()){ ... } // true or false
/*********************************************************************************************/
var viewportCheck = (function(){
  var isSP = function(){
    return $(window).width() < 769;
  };

  var isTB = function(){
    return ($(window).width() > 768) && ($(window).width() < 1280);
  };

  var isPC = function(){
    return $(window).width() > 1279;
  };

  return {
    isSP : isSP,
    isTB : isTB,
    isPC : isPC
  };
})();
/*********************************************************************************************/




/*********************************************************************************************/
// OSのバージョン判断
/*********************************************************************************************/
// iOS
function ios_ver(){
  var ios_ua = navigator.userAgent;
  if( ios_ua.indexOf("iPhone") > 0 ) {
    ios_ua.match(/iPhone OS (\w+){1,3}/g);
    var version = (RegExp.$1.replace(/_/g, '')+'00').slice(0,3);
    return version;
  }
}

// Android
function and_ver(){
  var and_ua = navigator.userAgent;
  if( and_ua.indexOf("Android") > 0 ) {
    var version = parseFloat(and_ua.slice(and_ua.indexOf("Android")+8));
    return version;
  }
}
/*********************************************************************************************/



/*********************************************************************************************/
// スムーズスクロール
/*********************************************************************************************/
var isHtmlScroll = (function(){
  var html = $('html'), top = html.scrollTop();
  var el = $('<div/>').height(10000).prependTo('body');
  html.scrollTop(10000);
  var rs = !!html.scrollTop();
  html.scrollTop(top);
  el.remove();
  return rs;
})();

function smoothScroll(target, callback){
  var speed = 1600;
  var easing = 'easeOutExpo';
  //var t = ( window.chrome || 'WebkitAppearance' in document.documentElement.style )? 'body' : 'html';
  var t = $(isHtmlScroll ? 'html' : 'body');
  $(t).queue([]).stop();
  var $targetElement = $(target);
  var scrollTo = $targetElement.offset().top;
  var maxScroll;
  if (window.scrollMaxY) {
    maxScroll = window.scrollMaxY;
  } else {
    maxScroll = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  }
  if (scrollTo > maxScroll){
    scrollTo = maxScroll;
  }
  $(t).stop(true,true).animate({ scrollTop: scrollTo }, speed, easing, function(){
    if(typeof callback === 'function' && callback()){
      callback();
    }
  });
}
/*********************************************************************************************/


/*********************************************************************************************/
// スロール位置に合わせてclass追加
/*********************************************************************************************/
(function($){
  $.fn.scrollClass = function(c){
    var defaults = {};
    var config = $.extend(defaults, c);
    var target = this;
    var _window = $(window);

    function addAction(){
      var length = target.length;
      for(var i=0; i<length; i++){
        if(target.eq(i).hasClass('action')) continue;

        var in_position = target.eq(i).offset().top + 200;
        //var in_position = target.eq(i).offset().top + (_window.height()/3);
        var window_bottom_position = _window.scrollTop() + _window.height();
        if(in_position < window_bottom_position){
          target.eq(i).addClass('action');
        }
      }
    }
    addAction();

    $(window).on('scroll', function(){
      addAction();
    });
    return target;
  };
})(jQuery);
/*********************************************************************************************/



/*********************************************************************************************/
// 小数点切り捨て
// ex) floatFormat(0.1234, 2); -> 0.12
/*********************************************************************************************/
function floatFormat(number, n){
  var _pow = Math.pow(10 , n);

  return Math.round(number * _pow) / _pow;
}
/*********************************************************************************************/



/*********************************************************************************************/
// ループスライダー
/*********************************************************************************************/
var loopSlide = (function(){
  var loopSlide = {};

  var loopSpeed = 0; // 1秒で進む距離
  var loopTime = 30; // １周にかかる秒数

  loopSlide.init = function(target, speed){
    loopTime = speed;
    if(typeof loopTime === 'undefined') loopTime = 30;
    var _this = target;
    var selfWidth = _this.innerWidth();
    var findUl = _this.find('ul');
    var findLi = findUl.find('li');
    var listWidth = findLi.outerWidth();
    var listCount = findLi.length;
    var loopWidth = listWidth * listCount;
    var windowWidth = $(window).width();
    var cloneCount = Math.ceil(windowWidth / (loopWidth*2));
    if(cloneCount < 2) cloneCount = 2;
    loopSpeed = (loopWidth) / loopTime;

    findUl.wrapAll('<div class="loopSliderWrap cf" />');
    var selfWrap = _this.find('.loopSliderWrap');
    findUl.css({width:loopWidth}).clone().appendTo(selfWrap);
    selfWrap.css({
      width:loopWidth*cloneCount,
      'transform':'translate(0, 0)'
    }).attr({
      'data-width':loopWidth,
      'data-speed':loopSpeed,
      'data-time':loopTime
    });
  };



  loopSlide.start = function(targetUl, type, speed){
    loopTime = speed;
    var targetLoopWidth = targetUl.attr('data-width');
    var targetLoopSpeed = parseInt(targetUl.attr('data-speed'));
    var targetLoopTime = targetUl.attr('data-time');

    targetUl.off('transitionend');

    if(type == 'left_to_right'){
      targetLoopWidth = (targetLoopWidth);
    }
    else {
      targetLoopWidth = (targetLoopWidth)*-1;
    }

    targetUl.css({
      'transition-duration':targetLoopTime+'s',
      'transform':'translate('+ targetLoopWidth +'px, 0)'
    }).on('transitionend', function(){
      targetUl.css({
        'transition-duration':'0s',
        'transform':'translate(0, 0)'
      }).attr({
        'data-speed':targetLoopSpeed,
        'data-time':loopTime
      });

      setTimeout(function(){
        loopSlide.start(targetUl, type);
      }, 1);
    });
  };


  loopSlide.stop = function(targetUl, type, speed){
    loopTime = speed;
    var transrate = targetUl.css('transform').match(/(-?[0-9\.]+)/g);
    var tran_x = transrate[4];
    var tran_y = transrate[5];

    var nokori;
    if(type == 'left_to_right'){
      nokori = parseInt(targetUl.attr('data-width')) - parseInt(tran_x);
    }
    else {
      nokori = parseInt(tran_x) + parseInt(targetUl.attr('data-width'));
    }

    var targetLoopSpeed = parseInt(targetUl.attr('data-speed'));
    var jikan = 5;

    var jikan2 = nokori/targetLoopSpeed;
    jikan2 = floatFormat( jikan2, 1 );

    // console.log('残り距離：'+nokori);
    // console.log('速度/px：'+targetLoopSpeed);
    // console.log('時間/sec：'+jikan2);

    targetUl.css({
      'transition-duration':'0s',
      'transform' : 'translate(' + tran_x + 'px,' + tran_y + 'px)'
    }).attr({
      'data-speed':targetLoopSpeed,
      'data-time':jikan2
    });
  };

  return loopSlide;
})();
/*********************************************************************************************/



/*********************************************************************************************/
// ツールチップ
/*********************************************************************************************/
function tooltip(){
  var toolTipHtml = '<div class="tooltip"></div>';

  $('#courseList').find('a').on({
  'mouseenter':function(ev){
    var _this = $(this);
    var text = _this.find('img').attr('alt');
    var x = ev.pageX;
    var y = ev.pageY;
    $('body').append(toolTipHtml);
    $('.tooltip').html(text).css({top: y + 34, left: x + 14});
  },

  'mousemove':function(ev){
    var _this = $(this);
    var text = _this.find('img').attr('alt');
    var x = ev.pageX;
    var y = ev.pageY;
    $('.tooltip').html(text).css({top: y + 34, left: x + 14});
  },

  'mouseleave':function(){
    $('.tooltip').remove();
  }
});
}
/*********************************************************************************************/



/*********************************************************************************************/
// youtube video control
/*********************************************************************************************/
function videoControl(action, targetID){
  var $playerWindow = $('#'+targetID)[0].contentWindow;
  $playerWindow.postMessage('{"event":"command","func":"'+action+'","args":""}', '*');
}
/*********************************************************************************************/
