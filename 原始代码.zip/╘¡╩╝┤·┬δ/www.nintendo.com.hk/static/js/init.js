/*
 *
 * File Name : init.js [use jquery]
 *
 */



var mk = (function(){
  var _window = $(window);
  var scrollTop = _window.scrollTop();
  var mvChara = $('#mvInner .obj .target_img');
  var t = $(isHtmlScroll ? 'html' : 'body');
  var _globalNavi = $('#globalNavi');
  var _gnav = _globalNavi.find('a');
  var contentPos = [];
  var contentColor = [];
  var _content = $('.section');
  var contentLength = _content.length;

  $(t).scrollTop(0);

  loading.loadImage(function(){
    $(t).scrollTop(0);

    // 初回アクセス動画
    //ov.firstMovie();
    
    
    // ループスライダー
    $('.loop_slide').each(function(){
      loopSlide.init($(this), 30);
    });

    // MVのキャラ配置
    mv.scaleMVSize(mvChara);

    // ツールチップ
    tooltip();

    // スムーススクロール
    $('a.scroll').on('click', function(){
      var hash = $(this).attr('href');
      smoothScroll(hash);
      return false;
    });

    // 表示領域外の時はCSSアニメーション停止
    $('.animate').on('inview', function(event, isInView, visiblePartX, visiblePartY){
      var _this = $(this);
      var _loopSliderWrap = _this.find('.loopSliderWrap');
      var type = _this.find('.loop_slide').attr('data-type');

      if(isInView){
        _this.removeClass('pause');

        if(_this.hasClass('img_line')){
          loopSlide.start(_loopSliderWrap, type, 30);
        }
      }
      else {
        _this.addClass('pause');

        if(_this.hasClass('img_line')){
          loopSlide.stop(_loopSliderWrap, type, 30);
        }
      }
    });

    // スクロールに合わせてclass追加
    $('.target').scrollClass();
    
    
    //ハッシュを確認する
    var URL = window.location.href ;
    
    if( location.hash == "#movieContents" )
    {
        ov.firstMovie();
        console.log( "movie" );
    }
    else if( location.hash == "#characterContents" )
    {
        smoothScroll( location.hash );
    }
    else if( location.hash == "#courseContents" ) 
    {
        smoothScroll( location.hash );
    }
    else if( location.hash == "#itemContents" ) 
    {
        smoothScroll( location.hash );
    }
    else if( location.hash == "#battleContents" ) 
    {
        smoothScroll( location.hash );
    }
    
    console.log( location.hash );
    
    
    
  });
  
    //ポップアップ
    $('a.guidebook').click(function (e) {
        e.preventDefault();
        var newPopup;
        var options = "toolbar=no,menubar=yes,status=yes,scrollbars=yes,resizable=yes";
        newPopup = window.open(this.href, "updateWindow", "width=718,height=800" + options);
        newPopup.focus();
        return false;
    });
    
    

  var scrollNaviInit = function(){
    for(var i=0; i<contentLength; i++){
      var color = _content.eq(i).attr('data-color');
      var contentTop = Math.floor(_content.eq(i).offset().top);
      var contentBottom = Math.floor(contentTop + _content.eq(i).outerHeight(true));
      contentPos[i] = [contentTop, contentBottom];
      contentColor.push(color);
    }
    _gnav.removeClass('active');

    checkNavi();
  };


  var checkNavi = function(){
    var hitLine = scrollTop + _window.height() - 300;

    for(var i=0; i<contentLength; i++){
      if(_gnav.eq(i).hasClass('active')) continue;

      if(contentPos[i][0] <= hitLine && contentPos[i][1] >= hitLine){
        _gnav.removeClass('active').eq(i).addClass('active');

        if(contentColor[i] == 'wh'){
          _globalNavi.addClass('wh').removeClass('bk');
        }

        if (contentColor[i] == 'bk'){
          _globalNavi.addClass('bk').removeClass('wh');
        }
      }

      if(contentPos[0][0] >= hitLine){
        _gnav.removeClass('active');
      }
    }
  };

  _window.on('load', function(){
    scrollNaviInit();


    _window.on('scroll', function(){
      scrollTop = _window.scrollTop();
      checkNavi();
    });
  });


  _window.on('resize', function(){
    mv.scaleMVSize(mvChara);
    mv.scaleMVSize($('.obj5'));
  });
})();
