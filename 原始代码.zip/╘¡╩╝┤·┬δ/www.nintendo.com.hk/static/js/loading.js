/*
 *
 * File Name : loading.js [use jquery]
 *
 */



var loading = (function(){
  function no_scroll(){
    var scroll_event = 'onwheel' in document ? 'wheel' : 'onmousewheel' in document ? 'mousewheel' : 'DOMMouseScroll';
    $(document).on(scroll_event,function(e){e.preventDefault();});
  }

  function return_scroll(){
    var scroll_event = 'onwheel' in document ? 'wheel' : 'onmousewheel' in document ? 'mousewheel' : 'DOMMouseScroll';
    $(document).off(scroll_event);
  }


  function loadImage(callback){
    no_scroll();

    // LoadQueueのインスタンスを作成
    var queue = new createjs.LoadQueue();

    var timeStamp = new Date().getTime();

    // manifestを定義
    var manifest = [
      {src:'assets/images/common/bg_page-illust.jpg?' + timeStamp},
      {src:'assets/images/common/img_sfc-chara.png?' + timeStamp},
      {src:'assets/images/battle/ba_01.jpg?' + timeStamp},
      {src:'assets/images/battle/ba_02.jpg?' + timeStamp},
      {src:'assets/images/battle/ba_03.jpg?' + timeStamp},
      {src:'assets/images/battle/ba_04.jpg?' + timeStamp},
      {src:'assets/images/battle/ba_05.jpg?' + timeStamp},
      {src:'assets/images/battle/ba_06.jpg?' + timeStamp},
      {src:'assets/images/battle/ba_07.jpg?' + timeStamp},
      {src:'assets/images/battle/ba_08.jpg?' + timeStamp},
      {src:'assets/images/mv/bg_mv.jpg?' + timeStamp},
      {src:'assets/images/mv/img_chara-other.png?' + timeStamp},
      {src:'assets/images/mv/img_chara-other2.png?' + timeStamp},
      {src:'assets/images/mv/img_jugemu.png?' + timeStamp},
      {src:'assets/images/mv/img_koopa.png?' + timeStamp},
      {src:'assets/images/mv/img_mario.png?' + timeStamp},
      {src:'assets/images/mv/img_peach.png?' + timeStamp},
      {src:'assets/images/course/img_cup-sprite.png?' + timeStamp},
      {src:'assets/images/course/img_cup-sprite_off.png?' + timeStamp},
      {src:'assets/images/course/img_beginner.png?' + timeStamp},
      {src:'assets/images/course/img_timeattack.png?' + timeStamp},
      {src:'assets/images/course/detail/1-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/1-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/1-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/1-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/2-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/2-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/2-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/2-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/3-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/3-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/3-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/3-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/4-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/4-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/4-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/4-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/5-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/5-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/5-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/5-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/6-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/6-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/6-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/6-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/7-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/7-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/7-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/7-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/8-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/8-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/8-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/8-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/9-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/9-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/9-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/9-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/10-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/10-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/10-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/10-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/11-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/11-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/11-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/11-4.jpg?' + timeStamp},
      {src:'assets/images/course/detail/12-1.jpg?' + timeStamp},
      {src:'assets/images/course/detail/12-2.jpg?' + timeStamp},
      {src:'assets/images/course/detail/12-3.jpg?' + timeStamp},
      {src:'assets/images/course/detail/12-4.jpg?' + timeStamp},
      {src:'assets/images/item/img_double.png?' + timeStamp},
      {src:'assets/images/scene/img_mario.png?' + timeStamp},
      {src:'assets/images/scene/img_girl.png?' + timeStamp},
      {src:'assets/images/scene/img_link.png?' + timeStamp},
      {src:'assets/images/scene/img_shizue.png?' + timeStamp},
      {src:'assets/images/scene/img_baby-luigi.png?' + timeStamp},
      {src:'assets/images/scene/img_baby-mario.png?' + timeStamp},
      {src:'assets/images/scene/img_baby-rosetta.png?' + timeStamp},

      {src:'assets/images/character/img_chara-sprite.png?' + timeStamp}
    ];

    queue.setMaxConnections(4); // 同時接続数を設定
    queue.loadManifest(manifest, true);
    queue.on('fileload', handleLoad);
    queue.on('progress', handleProgress);
    queue.on('complete', handleComplete);

    var loadingNum = 0;
    function handleProgress(evt){
      var tgt = Math.floor(evt.progress * 100);
      var speed = 10;

      setInterval(function(){
        if(loadingNum <= tgt){
        	//console.log(loadingNum + '%');
          $('#loadingBar').css({'width':'calc('+ loadingNum +'% - 4px)'});
        	loadingNum++;

          if(loadingNum == 100){
            //$('body').removeClass('noscroll');
            $('#mkLoading').addClass('hide');
            $('#mkOverlay').removeClass('hide').hide();
            $('#mkMainVisual').removeClass('deactive').addClass('action');
            $('#globalNavi').addClass('active');
            $('#ncommon-ghdr-header').addClass('show');

            if(typeof callback === 'function' && callback()){
              callback();
            }

            setTimeout(function(){
              $('#mkLoading').remove();
              return_scroll();
            }, 1400);
          }
        }
      }, speed);
    }

    function handleLoad(evt){
      // 読み込みが完了した画像
    }

    function handleComplete(evt){
    }
  }

  return {
    loadImage : loadImage
  };
})();
