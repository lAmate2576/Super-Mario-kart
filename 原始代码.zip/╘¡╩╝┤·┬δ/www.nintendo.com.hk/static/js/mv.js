/*
 *
 * File Name : mv.js [use jquery]
 *
 */



var mv = (function(){
  var fixScale;

  var scaleMVSize = function(target){
    var bgW = 1280;
    var bgH = 715;
    var winW = $(window).width();
    var winH = $(window).height();
    var scaleW = winW / bgW;
    var scaleH = winH / bgH;
    fixScale = Math.max(scaleW, scaleH);
    fixScale = floatFormat(fixScale, 2);

    target.css({'transform':'scale('+ fixScale +')'});
  };

  return {
    scaleMVSize : scaleMVSize
  };
})();
