!function(ntRedirect){
	// nt_redirect_config.js (ver.1)

	/*
	* コメントの説明に従ってご使用ください。
	* 説明コメントは、納品時に削除していただくようお願いします。
	*/

	/*
	* ＜１：ルートディレクトリの設定＞
	* 下記以外のディレクトリがサイトルートになる場合は、22行目にある関数でサイト
	* ルートを設定してください。
	* （これより深い階層に入れる場合も必要。20行目の記述はコースセレクションの例）
	*
	* wiiu/xxxx/
	* 3ds/xxxx/
	* 2ds/xxxx/
	* amiibo/xxxx/
	*
	* 記述例）/wiiu/amaj/course_selection/ 内にコンテンツを格納する場合
	* ntRedirect.setContentRoot("/wiiu/amaj/course_selection/");
	*/
	ntRedirect.setContentRoot("/switch/aabpa/");

	/*
	* ＜２：デバイス別のリダイレクトルールの設定＞
	* 下記のルールと異なるリダイレクトを行いたい場合は、37行目にある関数でルール
	* を設定してください。
	*
	* PC ⇒ PC版を表示
	* SP ⇒ SP版を表示
	* Wii U ⇒ PC版を表示
	* 3DS ⇒ SP版を表示
	* タブレット ⇒ PC版を表示
	*
	* 記述例）sp/ディレクトリを表示する対象にWii Uを追加する場合
	* ntRedirect.setRedirectRule("sp",["isMobile","is3DS","isWiiU"]);
	*/
	ntRedirect.setRedirectRule("3ds",[]);
	ntRedirect.setRedirectRule("sp",[]);
	ntRedirect.setRedirectRule("wiiu",[]);
	// ntRedirect.setRedirectRule("3ds",["is3DS"]);
	// ntRedirect.setRedirectRule("sp",["isMobile","isTablet"]);
	// ntRedirect.setRedirectRule("wiiu",["isWiiU"]);

	/*
	* ＜３：ページの対応関係の設定＞
	* 49行目～の配列内に、記述例に従って、PC版/SP版ページの対応関係を
	* サイトルート基準の相対パスで記述してください。
	* PC版の1ページに対して複数のSP版ページがある場合、SP版ページの数だけ記述が
	* 必要です。
	* なお、"/" と "/index.html" は区別して記述してください。
	* ＜１＞または＜２＞のみの変更を行って、ページの対応関係にイレギュラーなもの
	* がない場合も記述していただく必要があります。
	*
	* ["PCページ","SPページ"],
	*/


	var RedirectUrls=[
		["", "3ds/", "sp/", "wiiu/"],
		["#characterContents", "3ds/character/", "sp/character/", "wiiu/#characterContents"],
		["#courseContents", "3ds/course/", "sp/course/", "wiiu/#courseContents"],
		["#itemContents", "3ds/item/", "sp/item/", "wiiu/#itemContents"],
		["#battleContents", "3ds/battle/", "sp/battle/", "wiiu/#battleContents"],
        ["#movieContents", "3ds/movie/", "sp/movie/", "wiiu/movie/"],

		["index.html", "3ds/index.html", "sp/index.html", "wiiu/index.html"],
		["index.html#characterContents", "3ds/character/index.html", "sp/character/index.html", "wiiu/index.html#characterContents"],
		["index.html#courseContents", "3ds/course/index.html", "sp/course/index.html", "wiiu/index.html#courseContents"],
		["index.html#itemContents", "3ds/item/index.html", "sp/item/index.html", "wiiu/index.html#itemContent"],
		["index.html#battleContents", "3ds/battle/index.html", "sp/battle/index.html", "wiiu/index.html#battleContents"],
        ["index.html#movieContents", "3ds/movie/index.html", "sp/movie/index.html", "wiiu/movie/index.html"]
	];

	ntRedirect.getClsByURL=function(path){
		for(var i =0;i<RedirectUrls.length;i++){
			if(RedirectUrls[i][1] == path){
				return "3ds";
			}
			if(RedirectUrls[i][2] == path){
				return "sp";
			}
			if(RedirectUrls[i][3] == path){
				return "wiiu";
			}
		}
		return null;
	};
	ntRedirect.redirect=function(){
		var path=location.pathname;
		path=path.replace(ntRedirect.contentRoot,"");
		path=path.replace('/\/$/',"/index.html");
		var current_cls=this.getClsByURL(path);
		var cls=this.getClsByUA(path);
		if(cls == current_cls){
		}else{
			if(cls == "3ds"){
				for(var i=0;i<RedirectUrls.length;i++){
					if(RedirectUrls[i][0] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][1]);
						break;
					}
					if(RedirectUrls[i][2] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][1]);
						break;
					}
					if(RedirectUrls[i][3] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][1]);
						break;
					}
				}
			}else if(cls == "sp"){
				for(var i=0;i<RedirectUrls.length;i++){
					if(RedirectUrls[i][0] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][2]);
						break;
					}
					if(RedirectUrls[i][1] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][2]);
						break;
					}
					if(RedirectUrls[i][3] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][2]);
						break;
					}
				}
			}else if(cls == "wiiu"){
				for(var i=0;i<RedirectUrls.length;i++){
					if(RedirectUrls[i][0] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][3]);
						break;
					}
					if(RedirectUrls[i][1] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][3]);
						break;
					}
					if(RedirectUrls[i][2] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][3]);
						break;
					}
				}
			}else{
				for(var i=0;i<RedirectUrls.length;i++){
					if(RedirectUrls[i][1] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][0]);
						break;
					}
					if(RedirectUrls[i][2] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][0]);
						break;
					}
					if(RedirectUrls[i][3] == path){
						this.doRedirect(this.contentRoot+RedirectUrls[i][0]);
						break;
					}
				}
			}
		}
	};

}(ntRedirect);
