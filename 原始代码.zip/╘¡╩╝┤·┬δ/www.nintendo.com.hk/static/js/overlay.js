/*
 *
 * File Name : overlay.js [use jquery]
 *
 */



var ov = (function(){
  var swipeFlag = false;
  var modalFlag = false;
  var playTimer;

  // course
  var _cupBtn = $('#courseModalCup').find('a');
  var courseSwiper = new Swiper ('#courseModalListInner', {
    loop: true,
    nextButton: '.course_next',
    prevButton: '.course_prev',
    spaceBetween: 70,
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: 'auto',

    onInit : function(swiper){
      // $(document).on('click', '#courseModalListInner .stage', function(){
      //   var _this = $(this);
      //   var ytID = _this.attr('data-ytid');
      //   var ytBox = _this.find('.yt');
      //   var ytBoxID = ytBox.attr('id');
      //
      //   _this.find('.img').addClass('hide');
      //
      //   var youtubeHtml = '<iframe id="player_'+ ytBoxID +'" width="450" height="200" src="https://www.youtube.com/embed/'+ ytID +'?rel=0&amp;showinfo=0&enablejsapi=1&wmode=transparent&controls=0" frameborder="0" allowfullscreen></iframe>';
      //
      //   ytBox.append(youtubeHtml);
      //
      //   setTimeout(function(){
      //     videoControl('mute', 'player_'+ytBoxID);
      //     videoControl('playVideo', 'player_'+ytBoxID);
      //   },1000);
      // });
    },

    onSlideChangeStart : function(swiper){
      var _this = $('#courseModalListInner').find('.swiper-slide-active');
      var cupID = _this.attr('data-cup');

      _cupBtn.removeClass('active').eq(cupID).addClass('active');
    },

    onSlideChangeEnd : function(swiper){
      var _this = $('#courseModalListInner').find('.stage').eq(swiper.snapIndex);
      var ytID = _this.attr('data-ytid');

      $('.swiper-wrapper').find('iframe').remove();
      $('.swiper-wrapper').find('.img').removeClass('hide');


      if(ytID && modalFlag === true){
        _this.find('.img').addClass('hide');
        var ytBox = _this.find('.yt');
        var ytBoxID = ytBox.attr('id');

        var youtubeHtml = '<iframe id="player_'+ ytBoxID +'" width="450" height="200" src="https://www.youtube.com/embed/'+ ytID +'?rel=0&amp;showinfo=0&enablejsapi=1&loop=1&playlist='+ ytID +'&wmode=transparent&autoplay=1" frameborder="0" allowfullscreen></iframe>';

        ytBox.append(youtubeHtml);

        // $('#player_'+ ytBoxID).ready(function(){
        //   setTimeout(function(){
        //     videoControl('mute', 'player_'+ytBoxID);
        //     videoControl('playVideo', 'player_'+ytBoxID);
        //   }, 1000);
        // });
      }
    }
  });

  _cupBtn.on('click', function(){
    var _this = $(this);
    var cupID = _this.attr('data-slide-index');
    courseSwiper.slideTo(cupID);

    _cupBtn.removeClass('active');
    _this.addClass('active');
  });


  // character
  var charaSwiper = new Swiper ('#characterModalListInner', {
    loop: true,
    nextButton: '.chara_next',
    prevButton: '.chara_prev',
    spaceBetween: 60,
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: 'auto',

    onSlideChangeEnd : function(swiper){
      var _this = $('#characterModalListInner').find('.movie').eq(swiper.snapIndex);
      var ytID = _this.attr('data-ytid');

      $('#characterModalList .swiper-wrapper').find('iframe').remove();
      if(ytID && modalFlag === true){
        var ytBox = _this.find('.yt');
        var ytBoxID = ytBox.attr('id');

        var youtubeHtml = '<iframe id="player_'+ ytBoxID +'" width="450" height="200" src="https://www.youtube.com/embed/'+ ytID +'?rel=0&amp;showinfo=0&enablejsapi=1&loop=1&playlist='+ ytID +'&wmode=transparent&controls=0&autoplay=1" frameborder="0" allowfullscreen></iframe>';

        ytBox.append(youtubeHtml);

        // $('#player_'+ ytBoxID).ready(function(){
        //   setTimeout(function(){
        //     videoControl('mute', 'player_'+ytBoxID);
        //     videoControl('playVideo', 'player_'+ytBoxID);
        //   }, 1000);
        // });
      }
    }
  });


  // item
  var itemSwiper = new Swiper ('#itemModalListInner', {
    loop: true,
    nextButton: '.item_next',
    prevButton: '.item_prev',
    spaceBetween: 100,
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: 'auto',

    onSlideChangeEnd : function(swiper){
      var _this = $('#itemModalListInner').find('.item').eq(swiper.snapIndex);
      var ytID = _this.attr('data-ytid');

      $('.swiper-wrapper').find('iframe').remove();
      if(ytID && modalFlag === true){
        var ytBox = _this.find('.yt');
        var ytBoxID = ytBox.attr('id');

        var youtubeHtml = '<iframe id="player_'+ ytBoxID +'" width="450" height="200" src="https://www.youtube.com/embed/'+ ytID +'?rel=0&amp;showinfo=0&enablejsapi=1&loop=1&playlist='+ ytID +'&wmode=transparent&controls=0&autoplay=1" frameborder="0" allowfullscreen></iframe>';

        ytBox.append(youtubeHtml);

        // $('#player_'+ ytBoxID).ready(function(){
        //   setTimeout(function(){
        //     videoControl('mute', 'player_'+ytBoxID);
        //     videoControl('playVideo', 'player_'+ytBoxID);
        //   }, 1000);
        // });
      }
    }
  });


  var speed = 400;
  var easing = 'easeOutExpo';
  var _window = $(window);
  var scrollTop = _window.scrollTop();
  var beforeScrollTop = 0;
  var t = $(isHtmlScroll ? 'html' : 'body');

  var _html = $('html');
  var _body = $('body');
  var _mkOverlayBG = $('#mkOverlayBG');
  var _mkWrapper = $('#mkWrapper');
  var _mkOverlay = $('#mkOverlay');
  var _mkContainer = $('#mkContainer');
  var _mask = _mkOverlay.find('.mask');
  var _contents = _mkOverlay.find('.contents');
  var _btn_close = $('.btn_close');
  var _mainMovie = $('#mainMovie');
  var _movThumb = $('#movThumb');


  // modal open
  // $('.btn_modal').find('a').on('click', function(){
  $('.btn_modal.mk_movie').find('a').on('click', function(){
    var _this = $(this);
    var modalID = _this.attr('data-modal');
    var swiperID = _this.attr('data-id');
    var ytID = _this.attr('data-ytid');
    var _targetModal = $('#'+modalID);
    var _targetModalMask = _targetModal.find('.mask');

    modalFlag = true;

    _contents.hide();
    _targetModal.show();
    _targetModalMask.removeClass('close');
    _mkOverlayBG.fadeIn(speed, easing);

    if(modalID == 'deluxe'){
      _mkOverlayBG.addClass('white');
    }
    else {
      _mkOverlayBG.removeClass('white');
    }

    _mkOverlay.fadeIn(speed, easing, function(){
      _mkWrapper.addClass('scroll');
      _body.addClass('noscroll');

      // swiper slide
      if(modalID == 'courseModal'){
        courseSwiper.slideTo(swiperID);
      }
      else if(modalID == 'characterModal'){
        charaSwiper.slideTo(swiperID);
      }
      else if(modalID == 'itemModal'){
        itemSwiper.slideTo(swiperID);
      }

      // youtube set
      if(ytID){
        setYT(ytID);
      }

      setTimeout(function(){
        _targetModalMask.addClass('open');
      }, 400);
    });
  });


  // modal close
  _btn_close.on('click', function(){
    _mask.addClass('close');
    _mkOverlay.delay(speed).fadeOut(speed, easing, function(){
      _mask.removeClass('open');
      _mkOverlayBG.fadeOut(speed, easing, function(){
        // youtube reset
        _mainMovie.empty();
        $('.swiper-wrapper').find('iframe').remove();
        _mkWrapper.removeClass('scroll');
        _body.removeClass('noscroll');

        modalFlag = false;
      });
    });
  });


  // set youtube
  _movThumb.find('a').on('click', function(){
    var ytid = $(this).attr('data-ytid');

    setYT(ytid);
  });

  var setYT = function(ytid){
    var youtubeHtml = '<iframe width="920" height="520" src="https://www.youtube.com/embed/'+ ytid +'?rel=0&amp;showinfo=0&autoplay=1" frameborder="0" allowfullscreen></iframe>';
    _mainMovie.empty().append(youtubeHtml);
  };


  // first access
  var firstMovie = function(){
    setTimeout(function(){
      //if(!$.cookie('first')){
        var _targetModal = $('#movieModal');
        var _targetModalMask = _targetModal.find('.mask');
        var ytID = $('#btnMovie').find('a').attr('data-ytid');

        _contents.hide();
        _targetModal.show();
        _targetModalMask.removeClass('close');
        _mkOverlayBG.fadeIn(speed, easing);

        _mkOverlay.fadeIn(speed, easing, function(){
          _body.addClass('noscroll');

          // youtube set
          if(ytID){
            setYT(ytID);
          }

          setTimeout(function(){
            _targetModalMask.addClass('open');
          }, 400);
        });
      //}
      //$.cookie('first', 'show');
    }, 3000);
  };


  _window.on('scroll', function(){
    scrollTop = _window.scrollTop();
  });


  return {
    firstMovie : firstMovie
  };
})();
